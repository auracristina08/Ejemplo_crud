/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package usuario;

import conexion.conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author aurcr
 */
public class agregar {
  public static void main(String[] args) {
    conexion con = new conexion();
    Connection cn;
    Statement st;
    ResultSet rs;

    String nombre = "Christopher Wolstelhome";
    String dirección = "Avenue34-56";
    String teléfono = "3224569873";
    String correo_electrónico = "cwolstenhome@gmail.com";
    String contraseña = "Chris56478";

    String sql = "INSERT INTO usuario (nombre, dirección, teléfono, correo_electrónico, contraseña) VALUES (?, ?, ?, ?, ?)";
    try {
      Class.forName("com.mysql.cj.jdbc.Driver");
    } catch (ClassNotFoundException ex) {
      Logger.getLogger(agregar.class.getName()).log(Level.SEVERE, null, ex);
    }

    try {
      cn = con.getConection();
      PreparedStatement pstmt = cn.prepareStatement(sql);
      pstmt.setString(1, nombre);
      pstmt.setString(2, dirección);
      pstmt.setString(3, teléfono);
      pstmt.setString(4, correo_electrónico);
      pstmt.setString(5, contraseña);
      pstmt.executeUpdate();

      String selectSql = "SELECT * FROM usuario";
      rs = pstmt.executeQuery(selectSql);
      while (rs.next()) {
        System.out.println(rs.getInt("userID") + ":" + rs.getString("nombre") + "-" + rs.getString("dirección") + "-" + rs.getString("teléfono") + "-" + rs.getString("correo_electrónico") + "-" + rs.getString("contraseña"));
      }
    } catch (SQLException ex) {
      Logger.getLogger(agregar.class.getName()).log(Level.SEVERE, null, ex);
    }
  }
}

    

     
