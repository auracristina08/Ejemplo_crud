/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package usuario;

import conexion.conexion;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Esta clase realiza una consulta a la tabla 'usuario' en la base de datos 
 * y muestra los resultados de todos los registros.
 * 
 * @author aurcr
 */
public class consultar {
    public static void main (String[] args){
    // Creamos una instancia de la clase 'conexion' para conectar a la base de datos
    conexion con=new conexion();
    Connection cn;
    Statement st;
    ResultSet rs;
    
    // Intentamos cargar el driver de MySQL
    try{
     Class.forName("com.mysql.jdbc.Driver");
    }catch(ClassNotFoundException ex){
    // Si no se encuentra el driver, mostramos un error en los logs
        Logger.getLogger(consultar.class.getName()).log(Level.SEVERE, null, ex);    
    }
    try{
     // Establecemos la conexión con la base de datos
    cn=con.getConection();
    
    // Creamos un objeto Statement para ejecutar consultas SQL
    st=cn.createStatement();
    // Ejecutamos una consulta SQL que obtiene todos los registros de la tabla 'usuario'
      rs=st.executeQuery("SELECT * FROM usuario ");
    // Avanzamos al primer registro del resultado
    rs.next();
    
    // Recorremos el resultado y mostramos los datos de cada registro
    do{
    // Imprimimos los datos del usuario en el formato: userID: nombre-dirección-teléfono-correo_electrónico-contraseña
    System.out.println(rs.getInt("userID") + ":" + rs.getString("nombre") + "-" + rs.getString("dirección") + "-" + rs.getString("teléfono") + "-" + rs.getString("correo_electrónico") + "-" + rs.getString("contraseña"));
    
    }while (rs.next());
    
    
    }catch (SQLException ex){
    // En caso de error SQL, registramos el error en los logs
        Logger.getLogger(consultar.class.getName()).log(Level.SEVERE, null, ex);
    }
    
    }   
}

