/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package usuario;

import conexion.conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Esta clase permite agregar un nuevo registro a la tabla 'usuario' en la base de datos.
 * Luego muestra todos los registros de la tabla después de la inserción.
 * 
 * @author aurcr
 */
public class agregar {
  public static void main(String[] args) {
      // Creamos una nueva instancia de la clase conexion
    conexion con = new conexion();
    Connection cn;
    Statement st;
    ResultSet rs;

     // Definimos los datos que se van a insertar en la tabla 'usuario'
    String nombre = "Christopher Wolstelhome";
    String dirección = "Avenue34-56";
    String teléfono = "3224569873";
    String correo_electrónico = "cwolstenhome@gmail.com";
    String contraseña = "Chris56478";

     // Sentencia SQL para insertar los datos en la tabla 'usuario'
    String sql = "INSERT INTO usuario (nombre, dirección, teléfono, correo_electrónico, contraseña) VALUES (?, ?, ?, ?, ?)";
    try {
      // Cargamos el driver de MySQL (aunque es opcional en versiones más recientes)
      Class.forName("com.mysql.cj.jdbc.Driver");
    } catch (ClassNotFoundException ex) {
      // Mostramos un mensaje de error si no se encuentra el driver
      Logger.getLogger(agregar.class.getName()).log(Level.SEVERE, null, ex);
    }

    try {
       // Establecemos la conexión a la base de datos
      cn = con.getConection();
       // Preparamos la sentencia SQL
      PreparedStatement pstmt = cn.prepareStatement(sql);
      // Asignamos los valores a cada campo de la sentencia SQL
      pstmt.setString(1, nombre);
      pstmt.setString(2, dirección);
      pstmt.setString(3, teléfono);
      pstmt.setString(4, correo_electrónico);
      pstmt.setString(5, contraseña);
      // Ejecutamos la sentencia para insertar el registro
      pstmt.executeUpdate();

      // Realizamos una consulta para verificar que los datos se insertaron correctamente
      String selectSql = "SELECT * FROM usuario";
      rs = pstmt.executeQuery(selectSql);
      // Iteramos sobre los resultados obtenidos de la consulta
      while (rs.next()) {
       // Mostramos los datos del usuario
        System.out.println(rs.getInt("userID") + ":" + rs.getString("nombre") + "-" + rs.getString("dirección") + "-" + rs.getString("teléfono") + "-" + rs.getString("correo_electrónico") + "-" + rs.getString("contraseña"));
      }
    } catch (SQLException ex) {
        // En caso de error en la base de datos, mostramos un mensaje
      Logger.getLogger(agregar.class.getName()).log(Level.SEVERE, null, ex);
    }
  }
}

    

     
