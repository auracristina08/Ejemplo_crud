/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package usuario;

import conexion.conexion;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Esta clase permite actualizar un registro en la tabla 'usuario' en la base de datos.
 * Luego muestra el contenido actualizado de la tabla.
 * 
 * 
 * @author aurcr
 */
public class editar {
   public static void main (String[] args){
    // Creamos una instancia de la clase 'conexion' para conectarnos a la base de datos
    conexion con=new conexion();
    Connection cn;
    Statement st;
    ResultSet rs;
    
    // Definimos el ID del registro que queremos editar
    int id_editar=1;
    
     // Nuevos valores que queremos actualizar en el registro
    String new_nombre = "Matthew Bellamy";
    String new_dirección = "Avenue 15th with 7th";
    String new_teléfono = "3102947895";
    String new_correo_electrónico = "bellamymmu@gmail.com";
    String new_contraseña = "Mbell159$33";
    
    // Creamos la sentencia SQL para actualizar el registro con el ID especificado
    String sql = "UPDATE usuario set nombre='"+new_nombre+"',dirección='"+new_dirección+"',teléfono='"+new_teléfono+"',correo_electrónico='"+new_correo_electrónico+"',contraseña='"+new_contraseña+"'where userID="+id_editar;
    
    // Intentamos cargar el driver JDBC de MySQL
    try{
     Class.forName("com.mysql.jdbc.Driver");
    }catch(ClassNotFoundException ex){
    // Si no se encuentra el driver, registramos un error en los logs
        Logger.getLogger(editar.class.getName()).log(Level.SEVERE, null, ex);    
    }
    try{
     // Establecemos la conexión con la base de datos
    cn=con.getConection();
    
    // Creamos un objeto Statement para ejecutar la sentencia SQL
    st=cn.createStatement();
    
    // Ejecutamos la sentencia SQL para actualizar el registro
    st.executeUpdate(sql);
    
    // Ejecutamos una consulta SQL para obtener todos los registros de la tabla 'usuario
    rs=st.executeQuery("SELECT * FROM usuario ");
    rs.next(); // Avanzamos al primer registro del resultado
    
    // Iteramos sobre los registros obtenidos y mostramos los datos actualizados
    do{
    // Imprimimos los datos del usuario en el formato: userID: nombre-dirección-teléfono-correo_electrónico-contraseña
    System.out.println(rs.getInt("userID") + ":" + rs.getString("nombre") + "-" + rs.getString("dirección") + "-" + rs.getString("teléfono") + "-" + rs.getString("correo_electrónico") + "-" + rs.getString("contraseña"));
    
    }while (rs.next());// Continuamos mientras haya más registros

    
    
    }catch (SQLException ex){
        // En caso de error SQL, lo registramos en los logs
        Logger.getLogger(editar.class.getName()).log(Level.SEVERE, null, ex);
    }
    
    }   

   
}


