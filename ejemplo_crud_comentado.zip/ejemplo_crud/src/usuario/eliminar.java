/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package usuario;

import conexion.conexion;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Esta clase permite eliminar un registro de la tabla 'usuario' en la base de datos.
 * Luego muestra los registros restantes de la tabla.
 * 
 * @author aurcr
 */
public class eliminar {
    public static void main (String[] args){
    // Creamos una instancia de la clase 'conexion' para conectarnos a la base de datos
    conexion con=new conexion();
    Connection cn;
    Statement st;
    ResultSet rs;
    //dato a eliminar 
     int id_eliminar=3;
     
     // instruccion sql
     
     String sql= "DELETE fROM usuario where userID="+id_eliminar;
     
     // Intentamos cargar el driver JDBC de MySQL
     try{
     Class.forName("com.mysql.jdbc.Driver");
    }catch(ClassNotFoundException ex){
    // Si no se encuentra el driver, registramos un error en los logs
        Logger.getLogger(eliminar.class.getName()).log(Level.SEVERE, null, ex);    
    }
    try{
    // Establecemos la conexión con la base de datos
    cn=con.getConection();
    
    // Creamos un objeto Statement para ejecutar la sentencia SQL
    st=cn.createStatement();
    
     // Ejecutamos la sentencia SQL para eliminar el registro
    st.executeUpdate(sql);
    
    // Ejecutamos una consulta SQL para obtener todos los registros de la tabla 'usuario'
    rs=st.executeQuery("SELECT * FROM usuario ");
    rs.next(); // Avanzamos al primer registro del resultado
    
    // Iteramos sobre los registros restantes y mostramos sus datos
    do{
    // Imprimimos los datos del usuario en el formato: userID: nombre-dirección-teléfono-correo electrónico-contraseña
    System.out.println(rs.getInt("userID") + ":" + rs.getString("nombre") + "-" + rs.getString("dirección") + "-" + rs.getString("teléfono") + "-" + rs.getString("correo_electrónico") + "-" + rs.getString("contraseña"));
    
    }while (rs.next()); // Continuamos mientras haya más registros
    
    
    }catch (SQLException ex){
        // En caso de error SQL, lo registramos en los logs
        Logger.getLogger(eliminar.class.getName()).log(Level.SEVERE, null, ex);
    }
    
    }   
}
